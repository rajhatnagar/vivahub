<?php
require_once 'db.php';
echo "Database connection attempted. If it didn't exist, it should be created now.";
?>
